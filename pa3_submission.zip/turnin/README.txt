to build program: type "make"

to run:

./multi-lookup <# requester> <# resolver> <requester log> <resolver log> <./input/names1.txt> <./input/names2.txt> <./input/names3.txt> <etc>
